@extends('layouts.app')

@section('content')
<div class="row">
<div class="col-sm-12">
    @if(session()->get('success'))
        <div class="alert alert-success">
            {{ session()->get('success') }}  
        </div>
    @endif
    <h1 class="display-3">Skills</h1>   
    <div>
    <a style="margin: 19px;" href="{{ route('skills.create')}}" class="btn btn-primary">New Skills</a>
    </div>  
  <table class="table table-striped">
    <thead>
        <tr>
          <td>ID</td>
          <td>Technology</td>
          <td>Percentage</td>
          <td colspan = 2>Actions</td>
        </tr>
    </thead>
    <tbody>
        @foreach($skills as $key=>$emp)
        <tr>
            <td>{{$key+1}}</td>
            <td>{{$emp->Technology}} </td>
            <td>{{$emp->Percentage}} %</td>
            <td>
                <a href="{{ route('skills.edit',$emp->id)}}" class="btn btn-primary">Edit</a>
            </td>
            <td>
                <form action="{{ route('skills.destroy', $emp->id)}}" method="post">
                  @csrf
                  @method('DELETE')
                  <button class="btn btn-danger" type="submit">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
  </table>
<div>
</div>
@endsection
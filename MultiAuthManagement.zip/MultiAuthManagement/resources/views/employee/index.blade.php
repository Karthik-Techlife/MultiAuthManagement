@extends('layouts.app')

@section('content')
<div class="row">
<div class="col-sm-12">
    @if(session()->get('success'))
        <div class="alert alert-success">
            {{ session()->get('success') }}  
        </div>
    @endif
    <h1 class="display-3">Employee</h1>   
    <div>
    <a style="margin: 19px;" href="{{ route('employee.create')}}" class="btn btn-primary">New Employee</a>
    </div>  
  <table class="table table-striped">
    <thead>
        <tr>
          <td>ID</td>
          <td>Name</td>
          <td>Email</td>
          <td>Job Title</td>
          <td>City</td>
          <td>Country</td>
          <td colspan = 3>Actions</td>
        </tr>
    </thead>
    <tbody>
        @foreach($employee as $key=>$emp)
        <tr>
            <td>{{$key+1}}</td>
            <td>{{$emp->first_name}} {{$emp->last_name}}</td>
            <td>{{$emp->email}}</td>
            <td>{{$emp->job_title}}</td>
            <td>{{$emp->city}}</td>
            <td>{{$emp->country}}</td>
            <td>
                <a href="{{ route('employee.edit',$emp->id)}}" class="btn btn-primary">Edit</a>
            </td>
            <td>
                <a href="{{ route('empskills',$emp->id)}}" class="btn btn-info">View</a>
            </td>
            <td>
                <form action="{{ route('employee.destroy', $emp->id)}}" method="post">
                  @csrf
                  @method('DELETE')
                  <button class="btn btn-danger" type="submit">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
  </table>
<div>
</div>
@endsection
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Employee;
use App\User;
use App\Skills;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $employee = Employee::all();

        return view('employee.index', compact('employee'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('employee.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'first_name'=>'required',
            'last_name'=>'required',
            'email'=>'required'
        ]);

        $contact = new Employee([
            'first_name' => $request->get('first_name'),
            'last_name' => $request->get('last_name'),
            'email' => $request->get('email'),
            'job_title' => $request->get('job_title'),
            'city' => $request->get('city'),
            'country' => $request->get('country')
        ]);
        $contact->save();
        $user = new User([
            'email' => $request->get('email'),
            'is_admin' => 0,
            'password'=> bcrypt('123456'),
        ]);
        $user->save();
        return redirect('/employee')->with('success', 'Employee saved!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $employee = Employee::find($id);
        return view('employee.edit', compact('employee'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'first_name'=>'required',
            'last_name'=>'required'
        ]);

        $employee = Employee::find($id);
        $employee->first_name =  $request->get('first_name');
        $employee->last_name = $request->get('last_name');
        $employee->job_title = $request->get('job_title');
        $employee->city = $request->get('city');
        $employee->country = $request->get('country');
        $employee->save();

        return redirect('/employee')->with('success', 'Employee updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $skill = Skills::where('employee_id',$id);
        $skill->delete();
        $employee = Employee::find($id);
        $user = User::where('email',$employee->email);
        $user->delete();
        $employee->delete();

        return redirect('/employee')->with('success', 'employee deleted!');
    }

    public function empskills($id){
        $skills = Skills::where('employee_id',$id)->get();
        $employee = Employee::find($id);
        $dataPoints = [];

        foreach ($skills as $skill) {
            
            $dataPoints[] = [
                "name" => $skill['Technology'],
                "y" => floatval($skill['Percentage'])
            ];
        }
        $data = json_encode($dataPoints);
        //dd($dataPoints);
        return view('employee.view', compact('skills','employee','data'));
    }

    public function empskillsedit($skill_id,$emp_id){
        $skills = Skills::find($skill_id);
        return view('employee.skillsedit', compact('skills','emp_id'));
        
    }

    public function empskillsupdate(Request $request,$id){
        $emp_id = $request->emp_id;
        $request->validate([
            'Technology'=>'required',
            'Percentage'=>'required'
        ]);

        $skill = Skills::find($id);
        $skill->Technology =  $request->get('Technology');
        $skill->Percentage = $request->get('Percentage');
        $skill->save();

        return redirect()->route('empskills', $emp_id)->with('success', 'skills updated!');
        
    }

    public function empskillscreate($emp_id){
        return view('employee.skillscreate', compact('emp_id')); 
    }

    public function empskillsstore(Request $request ,$id)
    {
        $request->validate([
            'Technology'=>'required',
            'Percentage'=>'required'
        ]);

        $employee = $id;

        $skill = new skills([
            'Technology' => $request->get('Technology'),
            'Percentage' => $request->get('Percentage'),
            'employee_id' => $employee,
        ]);
        $skill->save();
        return redirect()->route('empskills', $employee)->with('success', 'skills saved!');
    }

    public function empskillsdestroy($skill_id,$emp_id)
    {
        $skill = Skills::where('id',$skill_id)->where('employee_id',$emp_id);
        $skill->delete();

        return redirect()->route('empskills', $emp_id)->with('success', 'skill deleted!');
    }
}
